package com.proyect_cafeteria_intellij.cafe_demo_intellij;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CafeDemoIntellijApplication {

	public static void main(String[] args) {
		SpringApplication.run(CafeDemoIntellijApplication.class, args);
	}

}
