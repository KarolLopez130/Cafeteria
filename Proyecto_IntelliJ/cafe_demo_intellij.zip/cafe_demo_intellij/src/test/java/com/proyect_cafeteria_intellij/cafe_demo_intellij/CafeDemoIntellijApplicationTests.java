package com.proyect_cafeteria_intellij.cafe_demo_intellij;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CafeDemoIntellijApplicationTests {

	@Test
	void contextLoads() {
	}

}
